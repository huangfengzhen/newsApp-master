import React,{Component} from "react";

export default class MobileSports extends Component{
  render(){
    return (
      <p>MobileSports</p>
    )
  }
}
