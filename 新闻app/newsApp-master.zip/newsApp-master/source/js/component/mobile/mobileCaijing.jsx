import React,{Component} from "react";

export default class MobileCaijing extends Component{
  render(){
    return (
      <p>MobileCaijing</p>
    )
  }
}
