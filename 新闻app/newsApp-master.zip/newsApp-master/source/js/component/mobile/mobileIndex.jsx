import React,{Component} from "react";

export default class MobileIndex extends Component{
  render(){
    return (
      <p>MobileIndex</p>
    )
  }
}
