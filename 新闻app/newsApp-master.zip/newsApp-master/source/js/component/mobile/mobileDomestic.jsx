import React,{Component} from "react";

export default class MobileDomestic extends Component{
  render(){
    return (
      <p>MobileDomestic</p>
    )
  }
}
