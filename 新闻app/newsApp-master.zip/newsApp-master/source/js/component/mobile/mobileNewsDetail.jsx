import React, {Component} from "react";
import {Card} from "antd";

export default class MobileNewsDetail extends Component {
  render(){
    return (
      <div></div>
    )
  }
}
