import React,{Component} from "react";

export default class MobileDisport extends Component{
  render(){
    return (
      <p>MobileDisport</p>
    )
  }
}
