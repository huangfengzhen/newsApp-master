import React,{Component} from "react";

export default class MobileFoot extends Component{
  render(){
    return (
      <p>MobileFoot</p>
    )
  }
}
