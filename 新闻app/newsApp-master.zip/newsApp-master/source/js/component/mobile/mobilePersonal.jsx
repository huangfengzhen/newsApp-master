import React,{Component} from "react";

export default class MobilePersonal extends Component{
  render(){
    return (
      <p>MobilePersonal</p>
    )
  }
}
