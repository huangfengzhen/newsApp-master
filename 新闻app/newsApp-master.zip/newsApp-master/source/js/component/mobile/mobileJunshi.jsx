import React,{Component} from "react";

export default class MobileJunshi extends Component{
  render(){
    return (
      <p>MobileJunshi</p>
    )
  }
}
